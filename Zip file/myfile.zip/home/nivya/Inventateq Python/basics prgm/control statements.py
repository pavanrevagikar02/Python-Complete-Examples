
a=20
if(a==10):
    print("if is executed only when the specified condition is true")

#
# '''a=40
# if(a>20):
#     print("somethng")'''
#
# #if else condition
#
# '''print("enter the value")
# a=int(input())
# if(a%2!=0):
#     print("odd")
# else:
#     print("not odd")'''

# elif condition

# print("enter the number")
# a=int(input())
# b=int(input())

# a=20
# b=30
# if(a>b) or (b<a):
#     print("logical or is done")
# elif (a<b) and (a<=b):
#     print("logical and is done")
# else:
#     print("not satsied with the condition")